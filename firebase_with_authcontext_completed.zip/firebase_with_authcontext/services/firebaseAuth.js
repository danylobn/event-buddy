import { auth } from "../firebaseConfig";
import * as Google from "expo-auth-session/providers/google";
import * as WebBrowser from "expo-web-browser";
import firebase from "firebase";
import * as AuthSession from "expo-auth-session";

WebBrowser.maybeCompleteAuthSession(); // necessário no topo

export const signUp = async (email, password) => {
  return await auth.createUserWithEmailAndPassword( email, password);
};

export const signIn = async (email, password) => {
  return await auth.signInWithEmailAndPassword( email, password);
};



// Cliente OAuth2 (consiga na tela do Firebase mais abaixo)
const CLIENT_ID = "";

