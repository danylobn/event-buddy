import * as Notifications from "expo-notifications";
import * as Permissions from "expo-permissions";
import { Platform } from "react-native";

// ⚙️ Configurações básicas
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

// 🔔 Solicita permissão do utilizador
export async function requestNotificationPermission() {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

// ⏰ Agenda uma notificação local
export async function scheduleNotification(title, body, dateTime) {
  const permissionGranted = await requestNotificationPermission();
  if (!permissionGranted) return;

  const triggerDate = new Date(dateTime);
  triggerDate.setMinutes(triggerDate.getMinutes() - 60); // Notifica 1h antes

  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
    },
    trigger: triggerDate,
  });
}
