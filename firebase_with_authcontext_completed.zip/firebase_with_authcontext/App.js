// App.js
import { useColorScheme } from "react-native";
import { LightTheme, DarkTheme } from "./temas/colors";
import { ThemeProvider, useThemeMode } from "./context/ThemeContext";
import { NavigationContainer, DarkTheme as NavDark, DefaultTheme as NavLight } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { AuthProvider, useAuth } from "./context/AuthContext";
import LoginScreen from "./screens/Login";
import SignupScreen from "./screens/Signup";
import MainTabs from "./navigation/MainTabs";
// ...
const Stack = createStackNavigator();

function AppNavigator() {
  const { user, loading } = useAuth();
  const { isDark } = useThemeMode();
 

  if (loading) return null;

  const navTheme = isDark ? NavDark : NavLight;

  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator>
        {user ? (
          <Stack.Screen name="Event Buddy" component={MainTabs} />
        ) : (
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Signup" component={SignupScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <AppNavigator />
      </ThemeProvider>
    </AuthProvider>
  );
}