

export const LightTheme = {
  background: "#ffffff",
  text: "#000000",
  card: "#f2f2f2",
  primary: "#6200ee",
};

export const DarkTheme = {
   background: "#1f1f1f",       // cinza escuro, mas não preto puro
  text: "#ffffff",             // texto branco
  card: "#2a2a2a",             // tom intermediário para blocos
  primary: "#bb86fc",
};
