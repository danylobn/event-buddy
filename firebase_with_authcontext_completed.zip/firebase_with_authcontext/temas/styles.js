


export const  styles =({
  

  title: {
    fontSize: 22,
    marginBottom: 30,
    textAlign: "center",
    fontWeight: "bold",
  },

  input: {
    borderRadius: 10,
    padding: 12,
    marginBottom: 15,
    fontSize: 16,
  },

  container: {
    
  },

  card: {
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
  },
 
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  image: {
    
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 20,
    alignSelf: "center",
    borderWidth: 2,   
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4, // Android

  },
  
});