import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import Home from "../screens/Home";
import DetalhesEvento from "../screens/DetalhesEvento";

const Stack = createStackNavigator();

export default function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="HomeList" component={Home} options={{ title: "Eventos" }} />
      <Stack.Screen name="DetalhesEvento" component={DetalhesEvento} options={{ title: "Detalhes do Evento" }} />
    </Stack.Navigator>
  );
}