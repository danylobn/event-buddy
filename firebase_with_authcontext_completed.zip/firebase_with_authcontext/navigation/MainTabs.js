import React from "react";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Favoritos from '../screens/Favoritos';
import Perfil from '../screens/Perfil';
import HomeStack from './HomeStack'
import { Ionicons } from '@expo/vector-icons';


const Tab = createBottomTabNavigator();

export default function MainTabs() {
  return (
    <Tab.Navigator
  screenOptions={({ route }) => ({
    headerShown: false,
    tabBarActiveTintColor: "#4CAF50",  // cor do ícone ativo
    tabBarInactiveTintColor: "gray",   // cor do ícone inativo
    tabBarIcon: ({ color, size, focused }) => {
      let iconName;

      if (route.name === "Início") {
        iconName = focused ? "home" : "home-outline";
      } else if (route.name === "Favoritos") {
        iconName = focused ? "heart" : "heart-outline";
      } else if (route.name === "Perfil") {
        iconName = focused ? "person" : "person-outline";
      }

      return <Ionicons name={iconName} size={size} color={color} />;
    },
  })}
>
  <Tab.Screen name="Início" component={HomeStack} />
  <Tab.Screen name="Favoritos" component={Favoritos} />
  <Tab.Screen name="Perfil" component={Perfil} />
</Tab.Navigator>

  );
}