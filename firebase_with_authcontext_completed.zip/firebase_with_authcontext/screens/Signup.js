import React, { useState } from "react";
import { View, TextInput, Text, Button, StyleSheet, ActivityIndicator, Alert, ScrollView } from "react-native";
import { signUp } from "../services/firebaseAuth";
import { useThemeMode } from "../context/ThemeContext";
import {styles} from "../temas/styles";

export default function SignupScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const { theme } = useThemeMode();

  const handleSignUp = async () => {
    if (!email || !password) {
      Alert.alert("Erro", "Preencha todos os campos.");
      return;
    }

    setLoading(true);
    try {
      await signUp(email, password);
      Alert.alert("Conta criada", "Você pode agora fazer login.");
      navigation.navigate("Login");
    } catch (error) {
      Alert.alert("Erro ao cadastrar", error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={[styles.container, { backgroundColor: theme.background }]}>
      <Text style={[styles.title, { color: theme.text }]}>Criar uma nova conta</Text>

      <TextInput
        placeholder="Email"
        placeholderTextColor="#aaa"
        style={[styles.input, { backgroundColor: theme.card, color: theme.text }]}
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
      />

      <TextInput
        placeholder="Senha"
        placeholderTextColor="#aaa"
        style={[styles.input, { backgroundColor: theme.card, color: theme.text }]}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      {loading ? (
        <ActivityIndicator color={theme.primary} style={{ marginVertical: 20 }} />
      ) : (
        <Button title="Cadastrar" onPress={handleSignUp} color={theme.primary} />
      )}

      <View style={{ marginTop: 20 }}>
        <Button title="Já tem conta? Entrar" onPress={() => navigation.navigate("Login")} />
      </View>
    </ScrollView>
  );
}


