import React, { useEffect, useState } from "react";
import { View, Text, Button, Image, TouchableOpacity, Alert } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { useAuth } from "../context/AuthContext";
import { database, storage } from "../firebaseConfig";
import { useThemeMode } from "../context/ThemeContext";
import {styles} from "../temas/styles";
import uuid from "react-native-uuid";



export default function Perfil() {
  const { user, logout } = useAuth();
  const [photoUrl, setPhotoUrl] = useState(null);
   const { toggleTheme, theme, isDark } = useThemeMode();
    const [localImage, setLocalImage] = useState(null);

  useEffect(() => {
      const unsub = database.collection("users").doc(user.uid).onSnapshot((doc) => {
      const photoUrl = doc.data()?.photoUrl;
      if (photoUrl) setPhotoUrl(photoUrl);;
    });
    return () => unsub();
  }, []);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (status !== "granted") {
      Alert.alert("Permissão necessária", "Permita acesso à galeria para selecionar uma imagem.");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
    allowsEditing: true,
    quality: 0.7,
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
  });

  if (!result.canceled) {
    const uri = result.assets[0].uri;
    setLocalImage(uri);
  }
  };//pickimage

const uploadProfileImage = async () => {
  try {
    if (!localImage) return;

    const response = await fetch(localImage);
    const blob = await response.blob();

    const filename = uuid.v4();
    const ref = storage.ref().child(`profileImages/${user.uid}/${filename}`);
    await ref.put(blob);

    const downloadUrl = await ref.getDownloadURL();

    // Salvar no Firestore
    await database.collection("users").doc(user.uid).set(
      { photoUrl: downloadUrl },
      { merge: true }
    );

    setPhotoUrl(downloadUrl);
    setLocalImage(null);
    alert("Imagem de perfil atualizada!");
  } catch (err) {
    console.log("Erro ao fazer upload da imagem:", err);
    alert("Erro ao fazer upload da imagem.");
  }
};





  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
            <Image
                source={
                  localImage
                    ? { uri: localImage }
                    : photoUrl
                    ? { uri: photoUrl }
            : require("../assets/default-profile.png")
            }
          style={ styles.image }
/>

      <Button title="Selecionar Imagem" onPress={pickImage} />
      {localImage && <Button title="Salvar Imagem" onPress={uploadProfileImage} color="green" />}

      <Text style={{ color: theme.text, marginBottom: 20 }}>Email: {user?.email}</Text>
      <Text style={{ color: theme.text, marginBottom: 20 }}>UID: {user?.uid}</Text>

      <Button title="Logout" onPress={logout} color={theme.primary} />

      <View style={{ marginTop: 20 }} />
      <Button
        title={`Alternar para modo ${isDark ? "claro" : "escuro"}`}
        onPress={toggleTheme}
        color={theme.primary}
      />


    </View>
  );
}
