import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from "react-native";
import { database,FieldValue  } from "../firebaseConfig";
import { useThemeMode } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";
import { Ionicons } from "@expo/vector-icons";
import { styles } from "../temas/styles";

export default function Home({ navigation }) {
  const [events, setEvents] = useState([]);
  const [filteredEvents, setFilteredEvents] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [favorites, setFavorites] = useState([]);
  const { theme } = useThemeMode();
  const { user } = useAuth();

  useEffect(() => {
    const unsubscribe = database
      .collection("events")
      .orderBy("datetime")
      .onSnapshot((snapshot) => {
        const data = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setEvents(data);
        setFilteredEvents(data);
      });

    return () => unsubscribe();
  }, []);

  // Escutar favoritos em tempo real
  useEffect(() => {
    const unsub = database.collection("users").doc(user.uid).onSnapshot((doc) => {
      setFavorites(doc.data()?.favorites || []);
    });
    return () => unsub();
  }, []);

const toggleFavorite = async (eventId) => {
  const ref = database.collection("users").doc(user.uid);
  const isFav = favorites.includes(eventId);

  try {
    await ref.update({
      favorites: isFav
        ? FieldValue.arrayRemove(eventId)
        : FieldValue.arrayUnion(eventId),
    });
  } catch (error) {
    console.log("Erro ao atualizar favoritos:", error);
  }
};
  const handleSearch = (text) => {
    setSearchQuery(text);
    const filtered = events.filter((event) => {
      const titleMatch = event.title?.toLowerCase().includes(text.toLowerCase());
      const locationMatch = event.localidade?.toLowerCase().includes(text.toLowerCase());
      return titleMatch || locationMatch;
    });
    setFilteredEvents(filtered);
  };

  const renderItem = ({ item }) => {
    const date = item.datetime?.toDate ? item.datetime.toDate() : new Date(item.datetime);
    const isFav = favorites.includes(item.id);

    return (
      <TouchableOpacity
        onPress={() => navigation.navigate("DetalhesEvento", { event: item })}
        style={{
          margin: 10,
          backgroundColor: theme.card,
          borderRadius: 10,
          overflow: "hidden",
        }}
      >
        <View style={{ position: "relative" }}>
          <Image source={{ uri: item.imageUrl }} style={{ height: 150 }} />
          <TouchableOpacity
            onPress={() => toggleFavorite(item.id)}
            style={{
              position: "absolute",
              top: 10,
              right: 10,
              backgroundColor: "rgba(0,0,0,0.4)",
              borderRadius: 20,
              padding: 6,
            }}
          >
            <Ionicons
              name={isFav ? "heart" : "heart-outline"}
              size={24}
              color={isFav ? "red" : "white"}
            />
          </TouchableOpacity>
        </View>
        <View style={{ padding: 10 }}>
          <Text style={{ color: theme.text, fontWeight: "bold" }}>{item.title}</Text>
          <Text style={{ color: theme.text }}>{date.toLocaleString()}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <TextInput
        placeholder="Pesquisar por título ou local..."
        value={searchQuery}
        onChangeText={handleSearch}
        style={{
          borderWidth: 1,
          borderColor: theme.card,
          borderRadius: 8,
          padding: 10,
          margin: 10,
          color: theme.text,
        }}
        placeholderTextColor={theme.text}
      />
      <FlatList
        data={filteredEvents}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 100 }}
      />
    </View>
  );
}
