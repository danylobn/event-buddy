import React, { useState } from "react";
import { View, TextInput, Text, Button, StyleSheet, ActivityIndicator, Alert, ScrollView } from "react-native";
import { signIn } from "../services/firebaseAuth";
import { useThemeMode } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";
import {styles} from "../temas/styles";
import { signInWithGoogleAsync } from "../services/firebaseAuth";
import * as Google from "expo-auth-session/providers/google";
import * as WebBrowser from "expo-web-browser";
import * as AuthSession from "expo-auth-session";
import firebase from "firebase";
import { auth } from "../firebaseConfig";

WebBrowser.maybeCompleteAuthSession();

export default function LoginScreen({ navigation }) {

  const [request, response, promptAsync] = Google.useAuthRequest({
  clientId: "354611425580-9me1f43h2vaic1rkd39s87n8rf76qv8e.apps.googleusercontent.com",
  redirectUri: AuthSession.makeRedirectUri({ useProxy: true }),
});

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
  if (response?.type === "success") {
    const { id_token } = response.params;
    const credential = firebase.auth.GoogleAuthProvider.credential(id_token);
    auth.signInWithCredential(credential);
  }
}, [response]);

  const { theme } = useThemeMode();
  const { user } = useAuth();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Erro", "Preencha todos os campos.");
      return;
    }

    setLoading(true);
    try {
      await signIn(email, password);
    } catch (error) {
      Alert.alert("Erro ao entrar", error.message);
    } finally {
      setLoading(false);
    }
     
  };
  

  return (
    <ScrollView contentContainerStyle={[styles.container, { backgroundColor: theme.background }]}>
      <Text style={[styles.title, { color: theme.text }]}>Entrar no Event Buddy</Text>
      

      <TextInput
        placeholder="Email"
        placeholderTextColor="#aaa"
        style={[styles.input, { backgroundColor: theme.card, color: theme.text }]}
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
      />

      <TextInput
        placeholder="Senha"
        placeholderTextColor="#aaa"
        style={[styles.input, { backgroundColor: theme.card, color: theme.text }]}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      {loading ? (
        <ActivityIndicator color={theme.primary} style={{ marginVertical: 20 }} />
      ) : (
        <Button title="Entrar" onPress={handleLogin} color={theme.primary} />
      )}

      <Button title="Entrar com Google" onPress={() => promptAsync()} color="#DB4437" />

      <View style={{ marginTop: 20 }}>
        <Button title="Criar Conta" onPress={() => navigation.navigate("Signup")} />
      </View>
    </ScrollView>
  );
}


