import React, { useEffect, useState } from "react";
import { View, Text, FlatList, Button, ActivityIndicator, StyleSheet,Image } from "react-native";
import { database, FieldValue } from "../firebaseConfig";
import { useAuth } from "../context/AuthContext";
import { useThemeMode } from "../context/ThemeContext";
import {styles} from "../temas/styles";

export default function Favoritos() {
  const { user } = useAuth();
  const { theme } = useThemeMode();

  const [favoritos, setFavoritos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = database.collection("users").doc(user.uid).onSnapshot(async (doc) => {
      const data = doc.data();
      const favIds = data?.favorites || [];

      if (favIds.length === 0) {
        setFavoritos([]);
        setLoading(false);
        return;
      }

      const promises = favIds.map((id) =>
        database.collection("events").doc(id).get()
      );
      const snapshots = await Promise.all(promises);

      const eventos = snapshots
        .filter((snap) => snap.exists)
        .map((snap) => ({ id: snap.id, ...snap.data() }));

      setFavoritos(eventos);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const removerFavorito = async (eventId) => {
    const userRef = database.collection("users").doc(user.uid);
    await userRef.update({
      favorites: FieldValue.arrayRemove(eventId),
    });
  };

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (favoritos.length === 0) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <Text style={{ color: theme.text }}>Nenhum favorito adicionado.</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={favoritos}
      keyExtractor={(item) => item.id}
      contentContainerStyle={{ padding: 10, backgroundColor: theme.background }}
      renderItem={({ item }) => (
        <View style={[styles.card, { backgroundColor: theme.card }]}>
          <Image
      source={{ uri: item.imageUrl }}
      style={styles.image}
      resizeMode="cover"
    />
          <Text style={[styles.title, { color: theme.text }]}>{item.title}</Text>
          <Text style={{ color: theme.text }}>{new Date(item.datetime.toDate()).toLocaleString()}</Text>
          <Button
            title="Remover dos favoritos"
            onPress={() => removerFavorito(item.id)}
            color="red"
          />
        </View>
      )}
    />
  );
}