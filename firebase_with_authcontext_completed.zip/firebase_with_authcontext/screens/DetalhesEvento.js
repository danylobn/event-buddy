import React, { useEffect, useState } from "react";
import { View, Text, Image, Button,ScrollView  } from "react-native";
import MapView, { Marker } from "react-native-maps";
import { database, FieldValue } from "../firebaseConfig";
import { useAuth } from "../context/AuthContext";
import { scheduleNotification } from "../services/notificationService";
import { useThemeMode } from "../context/ThemeContext";
import {styles} from "../temas/styles";



export default function DetalhesEvento({ route }) {
  const { event } = route.params;
  const { user } = useAuth();
  const [isParticipating, setIsParticipating] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [participantCount, setParticipantCount] = useState(event.participants?.length || 0);
   const date = event.datetime?.toDate ? event.datetime.toDate() : new Date(event.datetime);
const userRef = user ? database.collection("users").doc(user.uid) : null;
  const eventRef = database.collection("events").doc(event.id);
  const {theme} = useThemeMode();
  
useEffect(() => {
   if (!user || !userRef) return;
  setIsParticipating(event.participants?.includes(user.uid));

  const unsubscribe = userRef.onSnapshot((doc) => {
    const favorites = doc.data()?.favorites || [];
    setIsFavorite(favorites.includes(event.id));
  });

  return () => unsubscribe();
}, [event.id]);

  const handleToggleParticipation = async () => {
     if (!user || !userRef) return;
    try {
      const update = isParticipating
        ? FieldValue.arrayRemove(user.uid)
        : FieldValue.arrayUnion(user.uid);

      await eventRef.update({
        participants: update,
      });

       await scheduleNotification(
    "Evento Próximo",
    `O evento "${event.title}" começa em 1 hora!`,
    date
  );

      const userParticipationUpdate = isParticipating
        ? FieldValue.arrayRemove(event.id)
        : FieldValue.arrayUnion(event.id);

      await userRef.set(
        {
          participations: userParticipationUpdate,
        },
        { merge: true }
      );

      setIsParticipating(!isParticipating);
      setParticipantCount((prev) => prev + (isParticipating ? -1 : 1));
    } catch (err) {
      console.log("Erro ao atualizar participação:", err);
    }
  };

  const handleToggleFavorite = async () => {
     if (!user || !userRef) return;
    try {
      const update = isFavorite
        ? FieldValue.arrayRemove(event.id)
        : FieldValue.arrayUnion(event.id);

      await userRef.set(
        {
          favorites: update,
        },
        { merge: true }
      );

      setIsFavorite(!isFavorite);
    } catch (err) {
      console.log("Erro ao atualizar favoritos:", err);
    }
  };

  let latitude = 0;
  let longitude = 0;
  if (typeof event.location === "string") {
    const parts = event.location.split(",");
    latitude = parseFloat(parts[0]);
    longitude = parseFloat(parts[1]);
  } else if (typeof event.location === "object") {
    latitude = event.location.latitude;
    longitude = event.location.longitude;
  }

 

  

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.background }]}>
      <Image
        source={{ uri: event.imageUrl }}
        style={{ height: 200, borderRadius: 10 }}
        resizeMode="cover"
      />
      <Text style={{ color: theme.text, fontWeight: "bold" }}>{event.title}</Text>
      <Text style={{color: theme.text}}>{date.toLocaleString()}</Text>
      <Text style={{color: theme.text, marginVertical: 10 }}>{event.description}</Text>
      
       <Text style={{color: theme.text}}>Participantes: {participantCount}</Text>
      <Button title={isParticipating ? "Cancelar participação" : "Participar"}
        onPress={handleToggleParticipation} />
      <Button title={isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
        onPress={handleToggleFavorite} color ="orange" />

      <Text style={{ marginTop: 20, fontWeight: "bold",color: theme.text }}>Localização:</Text>

      <MapView
        style={{ height: 200, marginVertical: 10 }}
        initialRegion={{
          latitude: latitude || 0,
          longitude: longitude || 0,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }}
      >
        <Marker coordinate={{ latitude, longitude }} />
      </MapView>
    </ScrollView>
  );
}
