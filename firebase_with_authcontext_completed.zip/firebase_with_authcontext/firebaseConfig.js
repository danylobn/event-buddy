import firebase from "firebase";



/* ADICIONAR O FIREBASE CONFIG*/
const firebaseConfig = {
  apiKey: "AIzaSyCbE03ngXq3w5la5hhl7WKiLWn0xzUNOcM",
  authDomain: "projetofb-6f12a.firebaseapp.com",
  projectId: "projetofb-6f12a",
  storageBucket: "projetofb-6f12a.firebasestorage.app",
  messagingSenderId: "354611425580",
  appId: "1:354611425580:web:3a5ba9765cc6a55cf47c89",
  measurementId: "G-0KMC4YMWP2"
};

if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}


export const auth = firebase.auth();
export const database = firebase.firestore();
export const storage = firebase.storage(); 
export const FieldValue = firebase.firestore.FieldValue;