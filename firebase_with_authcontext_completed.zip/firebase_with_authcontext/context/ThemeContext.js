import React, { createContext, useContext, useState } from "react";
import { DarkTheme, LightTheme } from "../temas/colors";

const ThemeContext = createContext();

export const useThemeMode = () => useContext(ThemeContext);

export const ThemeProvider = ({ children }) => {
  const [isDark, setIsDark] = useState(false); // padrão claro

  const toggleTheme = () => setIsDark((prev) => !prev);

  const theme = isDark ? DarkTheme : LightTheme;

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme, theme }}>
      {children}
    </ThemeContext.Provider>
  );
};